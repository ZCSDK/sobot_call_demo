//
//  AppDelegate.h
//  SobotCallDemo
//
//  Created by lizh on 2021/12/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic,strong) UIWindow *window;
@end

