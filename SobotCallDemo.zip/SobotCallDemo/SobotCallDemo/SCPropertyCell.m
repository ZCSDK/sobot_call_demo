//
//  SCPropertyCell.m
//  SobotCallTest
//
//  Created by lizh on 2021/12/22.
//  Copyright © 2021 sobot. All rights reserved.
//

#import "SCPropertyCell.h"

@interface SCPropertyCell()<UITextFieldDelegate>

@property (nonatomic,strong)UILabel *titleLab;

@property (nonatomic,strong)UITextField *textField;

@end

@implementation SCPropertyCell

- (void)awakeFromNib{
    [super awakeFromNib];
    // Initialization code
    [self createItemsView];
}


-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self){
        self.userInteractionEnabled=YES;
        [self createItemsView];
    }
    return self;
}

-(void)createItemsView{
    _titleLab = [[UILabel alloc]initWithFrame:CGRectMake(5, 5, [UIScreen mainScreen].bounds.size.width - 10, 15)];
    _titleLab.font = [UIFont systemFontOfSize:13];
    _titleLab.textColor = [UIColor blackColor];
    [self addSubview:_titleLab];
    
    _textField = [[UITextField alloc]init];
    [self addSubview:_textField];
    _textField.frame = CGRectMake(5, CGRectGetMaxY(_titleLab.frame)+10, [UIScreen mainScreen].bounds.size.width - 10, 20);
    _textField.textColor = [UIColor blackColor];
    _textField.delegate = self;
    [_textField addTarget:self action:@selector(textValueChange:) forControlEvents:UIControlEventEditingChanged];
    _textField.returnKeyType = UIReturnKeyDone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)dataWithItem:(NSDictionary *)item{
//    @"index":@"1001",@"title_name":@"应用秘钥",@"type":@"1",@"value":info.client_secret.length > 0 ? info.client_secret : @""},
    _titleLab.text = item[@"title_name"];
    _textField.text = item[@"value"];
    _textField.tag = [item[@"index"] intValue];
}

-(void)textValueChange:(UITextField*)textField{
    if (self.delegate && [self.delegate respondsToSelector:@selector(textFiledValueChangeWith:)] ) {
        [self.delegate textFiledValueChangeWith:textField];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (self.delegate && [self.delegate respondsToSelector:@selector(tfDidBeginEditing:)]) {
        [self.delegate tfDidBeginEditing:textField];
    }
}


@end
