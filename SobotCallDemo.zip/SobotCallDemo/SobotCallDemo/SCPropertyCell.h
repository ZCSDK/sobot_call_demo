//
//  SCPropertyCell.h
//  SobotCallTest
//
//  Created by lizh on 2021/12/22.
//  Copyright © 2021 sobot. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol SCPropertyCellDelegate <NSObject>

-(void)textFiledValueChangeWith:(UITextField*)tf;

-(void)tfDidBeginEditing:(UITextField*)tf;
@end

@interface SCPropertyCell : UITableViewCell

@property (nonatomic,weak) id <SCPropertyCellDelegate> delegate;

-(void)dataWithItem:(NSDictionary *)item;

@end

NS_ASSUME_NONNULL_END
