//
//  SCConfigDetailView.h
//  SobotCallTest
//
//  Created by lizh on 2021/12/22.
//  Copyright © 2021 sobot. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SobotCall/SobotCallInfo.h>
NS_ASSUME_NONNULL_BEGIN

@protocol SCConfigDetailViewDelegate <NSObject>

-(void)buttonClick:(UIButton *)sender;

-(void)infoValueChange:(SobotCallInfo*)info;
@end

@interface SCConfigDetailView : UIView

@property (nonatomic,weak) id <SCConfigDetailViewDelegate> delegate;

-(instancetype)initWithFrame:(CGRect)frame info:(SobotCallInfo*)info phoneNumber:(NSString *)phoneNumber userNick:(NSString *)userNick;
@end

NS_ASSUME_NONNULL_END
