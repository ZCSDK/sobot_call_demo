//
//  SCConfigDetailView.m
//  SobotCallTest
//
//  Created by lizh on 2021/12/22.
//  Copyright © 2021 sobot. All rights reserved.
//

#import "SCConfigDetailView.h"
#import "SCPropertyCell.h"
#define cellSetIdentifier  @"SCPropertyCell"

@interface SCConfigDetailView()<SCPropertyCellDelegate,UITableViewDelegate,UITableViewDataSource>{
    UITextField *temptf;
}
@property (nonatomic,strong)UITableView *listView;
@property (nonatomic,strong) NSMutableArray * dataArray;

@property (nonatomic,copy) NSString *phoneNumber;
@property (nonatomic,copy) NSString *userNick;
@property (nonatomic,strong) SobotCallInfo *info;

@property (nonatomic,strong)UIButton *loginBtn;
@property (nonatomic,strong)UIButton *tokenLoginBtn;
@property (nonatomic,strong)UIButton *exitBtn;
@property (nonatomic,strong)UIButton *openCallBtn;
@property (nonatomic,strong)UIButton *callBtn;
@end

@implementation SCConfigDetailView

-(instancetype)initWithFrame:(CGRect)frame info:(SobotCallInfo*)info phoneNumber:(NSString *)phoneNumber userNick:(NSString *)userNick{
    self = [super initWithFrame:frame];
    if (self) {
        self.frame = frame;
        self.info = info;
        self.phoneNumber = phoneNumber;
        self.userNick = userNick;
        [self createUI];
        [self loadDataWithInfo:info];
    }
    return self;
}

-(void)loadDataWithInfo:(SobotCallInfo*)info{
    _dataArray = [NSMutableArray arrayWithCapacity:0];
    // 1.输入框 2.text
    NSArray *array = @[@{@"index":@"1001",@"title_name":@"应用秘钥",@"type":@"1",@"value":info.client_secret.length > 0 ? info.client_secret : @""},
                       @{@"index":@"1011",@"title_name":@"应用ID",@"type":@"1",@"value":info.appid.length > 0 ? info.appid : @""},
                       @{@"index":@"1002",@"title_name":@"企业ID",@"type":@"1",@"value":info.companyid.length > 0 ? info.companyid : @""},
                       @{@"index":@"1003",@"title_name":@"外显号码",@"type":@"1",@"value":info.display_number.length > 0 ? info.display_number : @""},
                       @{@"index":@"1004",@"title_name":@"技能组ID",@"type":@"1",@"value":info.groupid.length > 0 ? info.groupid :@""},
                       @{@"index":@"1005",@"title_name":@"坐席ID",@"type":@"1",@"value":info.agentid.length > 0 ? info.agentid :@""},
                       @{@"index":@"1006",@"title_name":@"SIP账号",@"type":@"1",@"value":info.sip_number.length > 0 ? info.sip_number :@""},
                       @{@"index":@"1007",@"title_name":@"SIP密码",@"type":@"1",@"value":info.sip_pwd.length > 0 ? info.sip_pwd :@""},
                       @{@"index":@"1008",@"title_name":@"外呼用户手机号",@"type":@"1",@"value":self.phoneNumber.length > 0 ? self.phoneNumber :@""},
                       @{@"index":@"1009",@"title_name":@"外呼用户昵称",@"type":@"1",@"value":self.userNick.length > 0? self.userNick :@""},
                       @{@"index":@"1010",@"title_name":@"登录token",@"type":@"1",@"value":info.access_token.length > 0 ? info.access_token : @""},
                      ];
    _dataArray = [NSMutableArray arrayWithArray:array];
    [self.listView reloadData];
}

-(void)createUI{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
    _listView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame)) style:UITableViewStylePlain];
    _listView.delegate = self;
    _listView.dataSource = self;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.autoresizesSubviews = YES;
    [self addSubview:_listView];
    [_listView registerClass:[SCPropertyCell class] forCellReuseIdentifier:cellSetIdentifier];
    
    UIView * footView = [[UIView alloc]initWithFrame:CGRectMake(0, 1, CGRectGetWidth(self.frame), 200)];
    footView.backgroundColor = [UIColor whiteColor];
    [self createFootViewWithFootView:footView];
    _listView.tableFooterView = footView;
    [_listView setSeparatorColor:[UIColor blackColor]];
    [_listView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLine];
     [self setTableSeparatorInset];
    if ([[UIDevice currentDevice].systemVersion doubleValue] >= 15.0) {
        _listView.sectionHeaderTopPadding = 0;
    }
}

-(void)createFootViewWithFootView:(UIView *)footView{
    UIView *lineview = [[UIView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), 1)];
    lineview.backgroundColor = [UIColor blackColor];
    [footView addSubview:lineview];
    NSArray *itemArray = @[@{@"title":@"登录",@"tag":@"2001"},
                           @{@"title":@"token登录",@"tag":@"2002"},
                           @{@"title":@"退出登录",@"tag":@"2003"},
                           @{@"title":@"拨号界面",@"tag":@"2004"},
                           @{@"title":@"打电话",@"tag":@"2005"}];
    CGFloat x = 10;
    CGFloat itemH = 60;
    CGFloat itemW = 100;
    CGFloat y = 20;
    for (int i = 0; i<itemArray.count; i++) {
        [self createItemButtonWithFrame:CGRectMake(x, y, itemW, itemH) tag:[itemArray[i][@"tag"] intValue] supView:footView title:itemArray[i][@"title"]];
        x = x + itemW + 20;
        if (x + itemW + 20 > [UIScreen mainScreen].bounds.size.width) {
            x = 10;
            y = y + itemH + 20;
        }
    }
        
}

-(UIButton *)createItemButtonWithFrame:(CGRect)frame tag:(int)tag supView:(UIView*)supView title:(NSString *)title {
    UIButton  *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag = tag;
    btn.frame = frame;
    [btn setBackgroundColor:[UIColor darkGrayColor]];
    btn.layer.cornerRadius = 5;
    btn.layer.masksToBounds = YES;
    [supView addSubview:btn];
    return  btn;
}

-(void)setTableSeparatorInset{
    UIEdgeInsets inset = UIEdgeInsetsMake(0, 10, 0, 0);
    if ([_listView respondsToSelector:@selector(setSeparatorInset:)]) {
        [_listView setSeparatorInset:inset];
    }
    if ([_listView respondsToSelector:@selector(setLayoutMargins:)]) {
        [_listView setLayoutMargins:inset];
    }
}

#pragma mark UITableView delegate Start
// 返回section数
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

// 返回section高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0;
}


-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

// 返回section下得行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _dataArray.count ;
}

// cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SCPropertyCell  *cell = [tableView dequeueReusableCellWithIdentifier:cellSetIdentifier];
    if (cell == nil) {
        cell = [[SCPropertyCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellSetIdentifier];
    }
    cell.delegate = self;
    [cell setBackgroundColor:[UIColor whiteColor]];
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    NSDictionary *item =_dataArray[indexPath.row];
    if(item){
        [cell dataWithItem:item];
    }
    return cell;
}

// table 行的高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

// table 行的点击事件
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


-(void)tfDidBeginEditing:(UITextField *)tf{
    temptf = tf;
}

-(void)buttonClick:(UIButton *)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(buttonClick:)]) {
        [self.delegate buttonClick:sender];
    }
}

-(void)textFiledValueChangeWith:(UITextField *)tf{
    switch (tf.tag) {
        case 1001:
        {
            self.info.client_secret = tf.text;
        }
            break;
        case 1002:
        {
            self.info.companyid = tf.text;
        }
            break;
        case 1003:
        {
            self.info.display_number = tf.text;
        }
            break;
        case 1004:
        {
            self.info.groupid = tf.text;
        }
            break;
        case 1005:
        {
            self.info.agentid = tf.text;
        }
            break;
        case 1006:
        {
            self.info.sip_number = tf.text;
        }
            break;
        case 1007:
        {
            self.info.sip_pwd = tf.text;
        }
            break;
        case 1008:
        {
            self.phoneNumber = tf.text;
        }
            break;
        case 1009:
        {
            self.userNick = tf.text;
        }
            break;
        case 1010:
        {
            self.info.access_token = tf.text;
        }
        case 1011:
        {
            self.info.appid = tf.text;
        }
            break;
        default:
            break;
    }
    NSDictionary *dict = @{@"client_secret":self.info.client_secret.length > 0 ? self.info.client_secret : @"",
                           @"companyid":self.info.companyid.length > 0? self.info.companyid : @"",
                           @"display_number":self.info.display_number.length > 0 ? self.info.display_number :@"",
                           @"groupid":self.info.groupid.length > 0 ? self.info.groupid : @"",
                           @"agentid":self.info.agentid.length > 0 ? self.info.agentid : @"",
                           @"sip_number":self.info.sip_number.length > 0 ? self.info.sip_number : @"",
                           @"sip_pwd":self.info.sip_pwd.length > 0 ? self.info.sip_pwd :@"",
                           @"phoneNumber":self.phoneNumber.length > 0 ? self.phoneNumber : @"",
                           @"userNick":self.userNick.length > 0 ? self.userNick :@"",
                           @"access_token":self.info.access_token.length > 0 ? self.info.access_token :@"",
                           @"appid":self.info.appid.length > 0 ? self.info.appid :@""
    };
    [[NSUserDefaults standardUserDefaults] setObject:dict forKey:@"info"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    if (self.delegate && [self.delegate respondsToSelector:@selector(infoValueChange:)]) {
        [self.delegate infoValueChange:self.info];
    }
}


#pragma mark -  //键盘显示
- (void)keyboardWillShow:(NSNotification *)notification {
    float animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    CGFloat keyboardH = [[[notification userInfo] objectForKey:@"UIKeyboardBoundsUserInfoKey"] CGRectValue].size.height;
    NSLog(@"键盘的高度%f",keyboardH);
    if (temptf != nil) {
        UIWindow * window=[[[UIApplication sharedApplication] delegate] window];
        CGRect rect=[temptf convertRect: temptf.bounds toView:window];
        NSLog(@"%f  ===  %f",(rect.origin.y + rect.size.height) ,([UIScreen mainScreen].bounds.size.height - keyboardH));
        if ((rect.origin.y + rect.size.height) > ([UIScreen mainScreen].bounds.size.height - keyboardH)) {
            CGRect sf = self.listView.frame;
            sf.origin.y = sf.origin.y - ((rect.origin.y + rect.size.height)-(self.frame.size.height - keyboardH) )-20;
            self.listView.frame = sf;
        }
    }
    
    NSNumber *curve = [notification.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:[curve intValue]];
    [UIView setAnimationDelegate:self];
    // commit animations
    [UIView commitAnimations];
}

//键盘隐藏
- (void)keyboardWillHide:(NSNotification *)notification {
    float animationDuration = [[[notification userInfo] valueForKey:UIKeyboardAnimationDurationUserInfoKey] floatValue];
    [UIView beginAnimations:@"bottomBarDown" context:nil];
    [UIView setAnimationDuration:animationDuration];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView commitAnimations];
    [UIView animateWithDuration:0.25 animations:^{
        self.listView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    }];
    
}


@end
