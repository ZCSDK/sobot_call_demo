//
//  ViewController.m
//  SobotPhoneLibTest
//
//  Copyright © 2019 sobot. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <SobotCall/ZCSobotCallApi.h>
#import <SobotCall/SobotCallInfo.h>
#import <SobotCall/SobotLog.h>
#import "SCConfigDetailView.h"
@interface ViewController ()<SCConfigDetailViewDelegate>{
    UITextField *temptf;
}
@property (nonatomic,strong) SobotCallInfo *info;

@property (nonatomic,copy)NSString *phoneNumber;// 电话号码

@property (nonatomic,copy)NSString *userNick;// 昵称

@property (nonatomic,strong)SCConfigDetailView *configView;
@end

@implementation ViewController

-(void)initConfig{
    SobotCallInfo *sobotCallInfo = [[SobotCallInfo alloc]init];
    NSDictionary *infoDict = [[NSUserDefaults standardUserDefaults] objectForKey:@"info"];
    if (infoDict != nil && [infoDict isKindOfClass:[NSDictionary class]]) {
        sobotCallInfo.companyid = infoDict[@"companyid"];
        sobotCallInfo.sip_number = infoDict[@"sip_number"];
        sobotCallInfo.appid = infoDict[@"appid"];
        sobotCallInfo.display_number = infoDict[@"display_number"];
        sobotCallInfo.groupid = infoDict[@"groupid"];
        sobotCallInfo.agentid = infoDict[@"agentid"];
        sobotCallInfo.sip_number = infoDict[@"sip_number"];
        sobotCallInfo.sip_pwd = infoDict[@"sip_pwd"];
        sobotCallInfo.access_token = infoDict[@"access_token"];
        sobotCallInfo.client_secret = infoDict[@"client_secret"];
        self.phoneNumber = infoDict[@"phoneNumber"];
        self.userNick = infoDict[@"userNick"];
        sobotCallInfo.sip_address = @"请联系售后人员获取该参数";
    }else{
#pragma Mark -- 以下测试数据演示使用  这里请使用您获取到在配置参数
//        sobotCallInfo.companyid = @"";
//        sobotCallInfo.sip_number = @"142160000";
//        sobotCallInfo.appid = @"a4b246c8b67e4543b3b870ce62f75546";
//        sobotCallInfo.client_secret = @"f6943eb4fbf144e2949d7538ee2cc665";
//        sobotCallInfo.agentid = @"969a7ee9fd4c42f48171b0128df2f16c";
//        sobotCallInfo.agent_phone_num = @"18600978969";
//        sobotCallInfo.groupid = @"36b0f8eb2de948d99e89c8f0c3d92e68_5";
////        sobotCallInfo.is_iecord_stereo = NO;
//        sobotCallInfo.sip_pwd = @"xjw2nz2a";
//        sobotCallInfo.display_number = @"01051393569";
//        sobotCallInfo.sip_address = @"39.105.93.78:7880";
//        self.phoneNumber = @"18510518890";
//        self.userNick = @"测试昵称";
    }
    _info = sobotCallInfo;
    SCUIConfig *uiconfig = [SCUIConfig new];
//    uiconfig.numberTextColor = [UIColor redColor];
//    uiconfig.charTextColor = [UIColor redColor];
//    uiconfig.accpetViewBgColor = [UIColor redColor];
//    uiconfig.callViewBgColor = [UIColor redColor];
    [ZCSobotCallApi getInstance].uiConfig = uiconfig;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initConfig];
    [SobotLog setDebug:YES];//默认为No
    [self configUI];
    
    [[ZCSobotCallApi getInstance] setCallListener:^(SobotVoipCallListenerState state) {
        
    }];
}

-(void)configUI{
    _configView = [[SCConfigDetailView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.view.frame), CGRectGetHeight(self.view.frame)) info:self.info phoneNumber:self.phoneNumber userNick:self.userNick];
    _configView.delegate = self;
    [self.view addSubview:_configView];
}

-(void)infoValueChange:(SobotCallInfo *)info{
    _info = info;
}
-(void)buttonClick:(UIButton*)sender{
    switch (sender.tag) {
        case 2001:
        {
            [[ZCSobotCallApi getInstance] loginWithSobotCallInfo:_info sobotCallListenBlock:^(id  _Nonnull object) {
                
            }];
        }
            break;
        case 2002:
        {
            if (self.info.access_token.length) {
                [[ZCSobotCallApi getInstance] loginWithTokenWithCallInfo:_info access_token:_info.access_token sobotCallListenBlock:^(id  _Nonnull object) {
                    
                }];
            }
        }
            break;
        case 2003:
        {
            [[ZCSobotCallApi getInstance] exitSobotCallWithSobotCallInfo:_info]; // 下班退出SDK
        }
            break;
        case 2004:
        {
            [[ZCSobotCallApi getInstance] openCallPhoneNumberWithPhoneNumber:self.phoneNumber.length ? self.phoneNumber : @"" userNick:self.userNick ? self.userNick :@"" sobotCallInfo:_info];
        }
            break;
        case 2005:
        {
            if (self.phoneNumber.length > 0) {
                [[ZCSobotCallApi getInstance] startCallWithPhoneNumber:self.phoneNumber userNick:self.userNick sobotCallInfo:_info];
            }else{
                [SobotLog logInfo:@"电话号码为空"];
            }
        }
            break;
            
        default:
            break;
    }
}

@end
