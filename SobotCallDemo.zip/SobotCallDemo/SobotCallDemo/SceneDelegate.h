//
//  SceneDelegate.h
//  SobotCallDemo
//
//  Created by lizh on 2021/12/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

